﻿namespace GolfGame.Model
{
    internal enum ElementTypeEnum
    {
        Ball = -1,
        Ditch = 1
    }
}
