﻿namespace GolfGame.DataManager
{
    using System;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Drawing.Drawing2D;

    using Model;

    internal static class Painter
    {
        private const int FrameSize = 10;
        private const int Scale = 20;
        private const int EllipseScale = 4;
        private const int ElementSize = 2;

        public static void DrawResult(OutputData data)
        {
            if (data.MaxX > 5000 || data.MaxY > 5000)
            {
                return;
            }

            var bitmap = new Bitmap((data.MaxX + FrameSize * 2) * Scale, (data.MaxY + FrameSize * 2) * Scale);
            var g = Graphics.FromImage(bitmap);
            g.Clear(Color.White);

            for (var i = 0; i < (data.MaxX + FrameSize * 2) * Scale; i += FrameSize)
            {
                var gpath = new GraphicsPath();
                gpath.StartFigure();
                gpath.AddLine(i + ElementSize / 2, 0 + ElementSize / 2, i + ElementSize / 2, (data.MaxY + FrameSize * 2) * Scale + ElementSize / 2);
                gpath.CloseFigure();
                g.DrawPath(Pens.LightGray, gpath);
            }

            for (var i = 0; i < (data.MaxY + FrameSize * 2) * Scale; i += FrameSize)
            {
                var gpath = new GraphicsPath();
                gpath.StartFigure();
                gpath.AddLine(0 + ElementSize / 2, i + ElementSize / 2, (data.MaxX + FrameSize * 2) * Scale + ElementSize / 2, i + ElementSize / 2);
                gpath.CloseFigure();
                g.DrawPath(Pens.LightGray, gpath);
            }

            foreach (var pair in data.MatchedPair)
            {
                var linePath = new GraphicsPath();
                linePath.StartFigure();
                linePath.AddLine(
                    (pair.Item1.X + FrameSize) * Scale + ElementSize / 2,
                    (pair.Item1.Y + FrameSize) * Scale + ElementSize / 2,
                    (pair.Item2.X + FrameSize) * Scale + ElementSize / 2,
                    (pair.Item2.Y + FrameSize) * Scale + ElementSize / 2);
                linePath.CloseFigure();
                g.FillPath(Brushes.Red, linePath);
                g.DrawPath(Pens.Red, linePath);

                var ellipse1Path = new GraphicsPath();
                ellipse1Path.StartFigure();
                ellipse1Path.AddEllipse(
                    (pair.Item1.X + FrameSize) * Scale - EllipseScale / 2,
                    (pair.Item1.Y + FrameSize) * Scale - EllipseScale / 2,
                    ElementSize * EllipseScale,
                    ElementSize * EllipseScale);   
                ellipse1Path.CloseFigure();
                g.FillPath(Brushes.Orange, ellipse1Path);
                g.DrawPath(Pens.Orange, ellipse1Path);

                var ellipse2Path = new GraphicsPath();
                ellipse2Path.StartFigure();
                ellipse2Path.AddEllipse(
                    (pair.Item2.X + FrameSize) * Scale - EllipseScale / 2,
                    (pair.Item2.Y + FrameSize) * Scale - EllipseScale / 2,
                    ElementSize * EllipseScale,
                    ElementSize * EllipseScale);
                ellipse2Path.CloseFigure();
                g.FillPath(Brushes.Green, ellipse2Path);
                g.DrawPath(Pens.Green, ellipse2Path);
            }

            var path = "..\\..\\..\\OutputData\\" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + data.Size + ".png";
            bitmap.Save(path, ImageFormat.Png);
        }
    }
}
